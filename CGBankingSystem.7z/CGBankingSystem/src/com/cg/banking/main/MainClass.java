package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl bankingServicesImpl=new BankingServicesImpl();
		int customerId=bankingServicesImpl.acceptCustomerDetails("Vishal", "Sai", "bank@gmail.com", "abc1000", "HYD", "TG", 500014, "HYDERABAD", "TELANGANA", 500001);
	
		Customer customer=bankingServicesImpl.getCustomerDetails(customerId);
		long accountNo=bankingServicesImpl.openAccount(customerId, "Savings", 800000f);
		
		int pin=bankingServicesImpl.generateNewPin(customerId, accountNo);
		float da=bankingServicesImpl.depositAmount(customerId, accountNo, 10000);
		float da2=bankingServicesImpl.depositAmount(customerId, accountNo, 20000);
		float da4=bankingServicesImpl.depositAmount(customerId, accountNo, 40000);
		//System.out.println(customer.getAccounts()[0].getPinNumber());
		//System.out.println(customer.getAccounts()[0].getTransactions()[0].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[1].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[2].getTransactionId());
		/*System.out.println(accountNo+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[0].getTransactionIdxCounter()+" "+customer.getAccounts()[0].getTransactions()[0].getAmount()+" "+da4);
		long accountNo1=bankingServicesImpl.openAccount(customerId, "Salary", 900000f);
		
		System.out.println(accountNo1+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[1].getTransactionIdxCounter());
		int pin1=bankingServicesImpl.generateNewPin(customerId, accountNo1);
		float da1=bankingServicesImpl.depositAmount(customerId, accountNo1, 20000);
		
		
long accountNo3=bankingServicesImpl.openAccount(customerId, "current", 1000000f);
		
		System.out.println(accountNo3+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[2].getTransactionIdxCounter());
		int pin3=bankingServicesImpl.generateNewPin(customerId, accountNo3);
		float da3=bankingServicesImpl.depositAmount(customerId, accountNo3, 50000);
		
		
		
		
		
		
		
		//System.out.println(customer.getAccounts()[0].getAccountNo()+" "+customer.getAccounts()[0].getAccountNo());
		//System.out.println(customerId+" "+accountNo+" "+pin+ " "+da+" "+customer.getAccountIdxCounter());
		//System.out.println(customerId+" "+accountNo1+" "+pin1+ " "+da1+" "+customer.getAccountIdxCounter());
		
		/*long accountNo1=bankingServicesImpl.openAccount(customerId, "Salary", 900000f);
		
		int pin1=bankingServicesImpl.generateNewPin(customerId, accountNo1);
		float da1=bankingServicesImpl.depositAmount(customerId, accountNo1, 50000);
		System.out.println(bankingServicesImpl.getCustomerDetails(customerId).toString());*/
	}
}
