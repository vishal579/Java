package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;

public class BankingServicesImpl implements BankingServices {
	private BankingDAOServicesImpl daoServicesImpl;
	public BankingServicesImpl() {
		daoServicesImpl=new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		
		return daoServicesImpl.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) {
		
		return daoServicesImpl.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {
		
		daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
		//float updatedBalance=this.getAccountDetails(customerId, accountNo).getAccountBalance()+amount;
		this.getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {
		while(getAccountDetails(customerId, accountNo)!=null&&getAccountDetails(customerId, accountNo).getPinCounter()<3){
		if(getAccountDetails(customerId, accountNo).getPinNumber()==pinNumber){
			daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
			float updatedBalance=this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount;
			this.getAccountDetails(customerId, accountNo).setAccountBalance(updatedBalance);
			getAccountDetails(customerId, accountNo).setPinCounter(0);
			return this.getAccountDetails(customerId, accountNo).getAccountBalance();
		}
		getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
		return 1;
		}
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
			if(getAccountDetails(customerIdFrom, accountNoFrom)!=null){
			if(daoServicesImpl.getCustomer(customerIdTo)==daoServicesImpl.getCustomer(customerIdFrom)){
				withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
				depositAmount(customerIdTo, accountNoTo, transferAmount);
				return true;
			}
			withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
			return true;
			}
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) {
		return daoServicesImpl.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {
		
		return daoServicesImpl.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
	
		return daoServicesImpl.generatePin(customerId, this.getAccountDetails(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {
		if(getAccountDetails(customerId, accountNo)==null)
		return false;
		if(getAccountDetails(customerId, accountNo).getPinNumber()==oldPinNumber)
			getAccountDetails(customerId, accountNo).setPinNumber(newPinNumber);
		return true;
	}

	@Override
	public Customer[] getAllCustomerDetails() {
		
		return daoServicesImpl.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {
		
		return daoServicesImpl.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {
		
		return daoServicesImpl.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {
		
		return null;
	}

}
