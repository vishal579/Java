public class fibonacci{
	public static void main(String [] str){
		int a=0,b=1,c,k=12;
		System.out.print(a);
		System.out.print(b);	
		for(int i=1;i<k+1;i++){
			c=a+b;
			System.out.print(c);
			a=b;
			b=c;	
		}
	}
}