public class conversion2{
	public static void main(String [] str){
		int v=111,v1=0,b=v,i=1,a;
		while(v>0){
			a=v%2;
			v=v/2;
			v1=v1+a*i;
			i=i*10;
		}
		System.out.print(v1);
	}
}
 