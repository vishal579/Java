public class MainClass7{
	public static void main(String [] str){
		for(int i=1;i<6;i++){
			for(int j=1;j<i;j++){
			System.out.print(" ");
			}
			for(int k=5;k>i-1;k--){
			System.out.print("v");
			}	
		System.out.println(" ");
		}
	}
}