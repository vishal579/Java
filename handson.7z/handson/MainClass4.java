public class MainClass4{
	public static void main(String [] str){
		for(int i=1;i<6;i++){
			for(int j=1;j<i+1;j++){
			System.out.print("v"+"\t" );
			}
		System.out.println(" ");
		}
	}
}
