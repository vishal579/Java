public class MainClass5.1{
	public static void main(String [] str){
		for(int i=1;i<6;i++){
			for(int j=5;j>i;j--){
			if(j>i){	
			System.out.print("\t");
			}
			else{
			for(int k=j;k<6;k--)
			System.out.print("v" );
			}
		System.out.println(" ");
		}
		}
	}
}
