public class palindrome{
	public static void main(String [] str){
		int v=12,v1=0,a,b=v;
		while(v>0){
			a=v%10;
			v=v/10;			
			v1=a+10*v1;
			//System.out.print(v1);
		}
		//System.out.print(v1);
		if(v1 == b)
		System.out.print("palindrome number");
		else
		System.out.print("not a palindrome number");
	}
}