public class MainClass6{
	public static void main(String [] str){
			
		for(int i=1;i<6;i++){
			for(int j=5;j>i;j--){
			System.out.print(" ");
			}
			for(int k=1;k<i+1;k++){
			System.out.print("v");
			}
			System.out.println(" ");	
		}
	}
}
	

