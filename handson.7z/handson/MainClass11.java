public class MainClass11{
	public static void main(String [] str){
		for(int i=1;i<=10;i++){
			for(int j=1;j<i;j++)
			System.out.print(" ");
			System.out.print(i);
			System.out.println(" ");
		}
		for(int i=10;i>1;i--){
			for(int j=i-1;j>1;j--)
			System.out.print(" ");
			System.out.print(i-1);
			System.out.println(" ");
		}
	}
}