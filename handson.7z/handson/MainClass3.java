public class MainClass3{
	public static void main(String [] str){
		for(int i=1;i<11;i++){
			for(int j=0;j<102;j=j+10){
			System.out.print(j+i + "\t" );
			}
		System.out.println(" ");
		}
	}
}
