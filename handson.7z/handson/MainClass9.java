public class MainClass9{
	public static void main(String [] str){
		for(int i=1;i<=5;i++){
			for(int j=5;j>i;j--)
			System.out.print(" ");
			for(int k=1;k<i+1;k++){
			System.out.print("v ");
			}
		System.out.println(" ");
		}
		for(int i=1;i<5;i++){
			for(int j=1;j<i+1;j++)
			System.out.print(" ");
			for(int k=5;k>i;k--){
			System.out.print("v ");
			}
		System.out.println(" ");
		}	
		
				
	}
}
