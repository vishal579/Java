public class OddEven{
	public static void main(String [] str){
		int a=1,b=20;
		System.out.println("even numbers ");	
		for(int i=a;i<=b;i++){
			if(i%2==0)
				System.out.print(i );	
		}
		System.out.println("odd numbers ");	
		for(int i=a;i<=b;i++){
			if(i%2!=0)
				System.out.print(i );	
		}
	}
}
 