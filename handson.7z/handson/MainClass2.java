public class MainClass2{
	public static void main(String [] str){
		for(int i=1;i<11;i++){
			for(int j=1;j<21;j++){
			System.out.print(j*i + "\t" );
			}
		System.out.println(" ");
		}
	}
}
