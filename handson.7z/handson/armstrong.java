public class armstrong{
	public static void main(String [] str){
		int v=371,c=0,v1=0,a,t=v,b=v;
		int k=1;
		while(b>0){
			b=b/10;
			c++;
		}
		while(v>0){
			a=v%10;
			v=v/10;	
			for(int i=1;i<=c;i++)
				k=k*a;
			v1=k+v1;	
			k=1;
		}
		if(v1 == t)
		System.out.print("armstrong number");
		else
		System.out.print("not a armstrong number");
	}
}