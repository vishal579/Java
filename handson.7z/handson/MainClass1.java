public class MainClass1{
	public static void main(String [] str){
		//int v;
		for(int v=1;v<11;v++)
		System.out.println(v);
	}
}