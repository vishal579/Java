public class MainClass5{
	public static void main(String [] str){
		for(int i=1;i<6;i++){
			for(int j=5;j>i-1;j--){
			System.out.print("v" );
			}
		System.out.println(" ");
		}
	}
}
