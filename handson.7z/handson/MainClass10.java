public class MainClass10{
	public static void main(String [] str){
		for(int i=1;i<11;i++){
			for(int j=10;j>i;j--)
			System.out.print("1");
			System.out.print("0");
			for(int k=1;k<i;k++)
			System.out.print("1");
		System.out.println(" ");	
		}
	}
}
