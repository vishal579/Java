public class Rearrange{
	public static void main(String [] str){
		int []a={1,2,3,4,5,6,7,8,9};
		int j=a.length-1;
		int k=j;	
		int [9] b={};
		for(int i=0;i<a.length;i++){
			b[j]=a[i];	
			j--;
		}
		j=0;
		for(int i=0;i<a.length;i=i*2+1){
			a[i]=b[j];
			j++;	
		}
		j=k;
		for(int i=0;i<a.length;i=i*2){
			a[i]=b[j];
			j--;	
		}					
	}
}
 