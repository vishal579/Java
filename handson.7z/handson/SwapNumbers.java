public class SwapNumbers{
	public static void main(String [] str){
		int a=12345,b=213240;
		a=a+b;
		b=a-b;
		a=a-b;		
		System.out.print(a);
		System.out.print(b);
	}
}
 