package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl bankingServicesImpl=new BankingServicesImpl();
		int customerId=bankingServicesImpl.acceptCustomerDetails("Vishal", "Sai", "bank@gmail.com", "abc1000", "HYD", "TG", 500014, "HYDERABAD", "TELANGANA", 500001);
		Customer customer=bankingServicesImpl.getCustomerDetails(customerId);
		//bankingServicesImpl.getCustomerDetails(customerId).setAccounts(new Account[3]);
		long accountNo=bankingServicesImpl.openAccount(customerId, "Savings", 800000f);
		//bankingServicesImpl.getAccountDetails(customerId, accountNo).setTransactions(new Transaction[5]);
		bankingServicesImpl.generateNewPin(customerId, accountNo);
		bankingServicesImpl.depositAmount(customerId, accountNo, 10000);
		
		
	}
}
