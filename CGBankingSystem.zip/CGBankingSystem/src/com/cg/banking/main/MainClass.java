package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl bankingServicesImpl=new BankingServicesImpl();
		int customerId=bankingServicesImpl.acceptCustomerDetails("Vishal", "Sai", "bank@gmail.com", "abc1000", "HYD", "TG", 500014, "HYDERABAD", "TELANGANA", 500001);
		Customer customer=bankingServicesImpl.getCustomerDetails(customerId);
		customer.setAccounts(new Account[3]);
		customer.getAccounts()[0]=new Account(pinNumber, pinCounter, "Savings", status, accountBalance, accountNo, transactions)
	}
}
